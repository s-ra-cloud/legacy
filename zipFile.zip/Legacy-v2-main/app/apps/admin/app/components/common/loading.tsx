export function LoadingView() {
  return (
    <div className="flex items-center justify-center p-8">
      <div className="h-8 w-8 animate-spin rounded-full border-gray-900 border-b-2"></div>
    </div>
  );
}
