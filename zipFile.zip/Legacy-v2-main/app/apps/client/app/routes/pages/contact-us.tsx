export default function ContactUsPage() {
  return (
    <div>
      <h1>Contact Us</h1>
      <p>If you have any questions, feel free to reach out!</p>
      <p>Mail: example@test.com</p>
    </div>
  );
}
