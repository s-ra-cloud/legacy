import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::requested-book.requested-book');
